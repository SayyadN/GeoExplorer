document.addEventListener('DOMContentLoaded', function() {
    const userGreeting = document.getElementById('user-greeting');
    const toggleDarkModeButton = document.getElementById('toggle-dark-mode');
    const body = document.body;
    const heroSection = document.querySelector('.hero-section');
    const footer = document.querySelector('footer');

    // Initialize Leaflet map
    const map = L.map('map', { center: [51.505, -0.09], zoom: 13 }); // Default view

    // Tile Layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Prompt user for name and display it
    function promptUserName() {
        const userName = prompt('Please enter your name:');
        if (userName && /^[a-zA-Z\s]+$/.test(userName)) {
            userGreeting.textContent = `Hello, ${userName}!`;
        } else {
            userGreeting.textContent = 'Hello, Guest!';
        }
    }
    
    // Call the function to prompt user for their name on page load
    promptUserName();

    // Toggle Dark Mode
    toggleDarkModeButton.addEventListener('click', function() {
        body.classList.toggle('dark-mode');
        heroSection.classList.toggle('dark-mode');
        footer.classList.toggle('dark-mode');
        const navbar = document.querySelector('.navbar');
        navbar.classList.toggle('dark-mode');
        
        if (body.classList.contains('dark-mode')) {
            toggleDarkModeButton.textContent = 'Light Mode';
        } else {
            toggleDarkModeButton.textContent = 'Dark Mode';
        }
    });
});